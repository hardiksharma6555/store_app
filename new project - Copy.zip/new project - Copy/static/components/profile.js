const profile = {
    template: `<div>

    Welcome to profile
    </div>`,
}




export default profile