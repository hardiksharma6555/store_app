const UserDashboard = {
  template: `<div>

  Welcome to User Dashoard
  </div>`,
}


export default UserDashboard