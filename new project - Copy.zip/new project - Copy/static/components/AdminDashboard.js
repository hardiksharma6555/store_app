const AdminDashboard = {
  template: `<div style="font-family: Arial, sans-serif;">
  <h1 style="font-size: 24px; margin-bottom: 20px;">{{ msg }}</h1>
  <h3>Available Sections</h3>
  <table style="width: 100%; border-collapse: collapse;">
    <tr>
      <th style="padding: 12px; background-color: #007bff; color: #fff;">Section ID</th>
      <th style="padding: 12px; background-color: #007bff; color: #fff;">Section Name</th>
      <th style="padding: 12px; background-color: #007bff; color: #fff;">Section Description</th>
      <th style="padding: 12px; background-color: #007bff; color: #fff;">Actions</th>
    </tr>
    <tr v-for="section in sections" :key="section.section_id">
      <td style="padding: 12px; text-align:center;">{{ section.section_id }}</td>
      <td style="padding: 12px; text-align:center;">{{ section.section_name }}</td>
      <td style="padding: 12px; text-align:center;">{{ section.section_description }}</td>
      <td style="padding: 12px; text-align:center;">
        <button @click="openEditModal(section)" style="background-color: #007bff; text-align:center;color: #fff; border: none; border-radius: 5px; cursor: pointer;">Edit</button>
        <button @click="confirmVenDelete(section.section_id)" style="background-color: #dc3545; text-align:center;color: #fff; border: none; border-radius: 5px; cursor: pointer;">Delete</button>
        <button @click="trigger_celery_job(section.section_id)" style="background-color: #dc3545; text-align:center; color: #fff; border: none; border-radius: 5px; cursor: pointer;">Export</button>
      </td>
    </tr>
  </table>

  <div v-if="editModalOpen" class="modal" style="display: block; position: fixed; z-index: 1; padding-top: 100px; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0, 0, 0, 0.4);">
    <div class="modal-content" style="background-color: #fefefe; margin: auto; padding: 20px; border: 1px solid #888; width: 80%;">
      <h3>Edit section</h3>
      <form @submit.prevent="updatesection">
        <label for="editSectionName">Section Name:</label>
        <input type="text" id="editSectionName" v-model="editSectionData.section_name" required>

        <label for="editSectionDescription">Section Description:</label>
        <textarea id="editSectionDescription" v-model="editSectionData.section_description" required></textarea>

        <button type="submit" style="background-color: #4CAF50; color: white; padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer;">Update Section</button>
      </form>
    </div>
  </div>

  <button type="button" @click="openCreatesectionPopup" style="padding: 10px 20px; background-color: #007bff; color: #fff; border: none; border-radius: 5px; cursor: pointer;">Create New Section</button>
  <div v-if="createsectionPopup" class="modal" style="display: block; position: fixed; z-index: 1; padding-top: 100px; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0, 0, 0, 0.4);">
    <div class="modal-content" style="background-color: #fefefe; margin: auto; padding: 20px; border: 1px solid #888; width: 50%;">
      <h3>Create New Section</h3>
      <form @submit.prevent="createsection">
        <label for="createSectionName">Section Name:</label>
        <input type="text" id="createSectionName" v-model="createSectionData.section_name" required>

        <label for="createSectionDescription">Section Description:</label>
        <textarea id="createSectionDescription" v-model="createSectionData.section_description" required></textarea>

        <button type="submit" style="background-color: #4CAF50; color: white; padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer;">Create Section</button>
      </form>
    </div>
  </div>

  <h3 style="margin-top: 20px;">Available Products</h3>
  <table style="width: 100%; border-collapse: collapse;">
    <tr>
      <th style="padding: 12px; background-color: #007bff; color: #fff;">Product ID</th>
      <th style="padding: 12px; background-color: #007bff; color: #fff;">Product Name</th>
      <th style="padding: 12px; background-color: #007bff; color: #fff;">Product Description</th>
      <th style="padding: 12px; background-color: #007bff; color: #fff;">Actions</th>
    </tr>
    <tr v-for="product in products" :key="product.product_id">
      <td style="padding: 12px; text-align:center;">{{ product.product_id }}</td>
      <td style="padding: 12px; text-align:center;">{{ product.product_name }}</td>
      <td style="padding: 12px; text-align:center;">{{ product.product_description }}</td>
      <td style="padding: 12px; text-align:center;">
        <button @click="openEditProduct(product)" style="background-color: #007bff; text-align:center;color: #fff; border: none; border-radius: 5px; cursor: pointer;">Edit</button>
        <button @click="confirmProductDelete(product.product_id)" style="background-color: #dc3545; text-align:center;color: #fff; border: none; border-radius: 5px; cursor: pointer;">Delete</button>
      </td>
    </tr>
  </table>

  <div v-if="editProductOpen" class="modal" style="display: block; position: fixed; z-index: 1; padding-top: 100px; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0, 0, 0, 0.4);">
    <div class="modal-content" style="background-color: #fefefe; margin: auto; padding: 20px; border: 1px solid #888; width: 80%;">
      <h3>Edit Product</h3>
      <form @submit.prevent="updateProduct">
        <label for="editProductName">Product Name:</label>
        <input type="text" id="editProductName" v-model="editProductData.product_name" required>

        <label for="editProductDescription">Product Description:</label>
        <textarea id="editProductDescription" v-model="editProductData.product_description" required></textarea>

        <button type="submit" style="background-color: #4CAF50; color: white; padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer;">Update Product</button>
      </form>
    </div>
  </div>

  <button type="button" @click="openCreateProductPopup" style="margin-top: 20px; padding: 10px 20px; background-color: #007bff; color: #fff; border: none; border-radius: 5px; cursor: pointer;">Create New Product</button>
  <div v-if="createProductPopup" class="modal" style="display: block; position: fixed; z-index: 1; padding-top: 90px; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0, 0, 0, 0.4);">
    <div class="modal-content" style="background-color: #fefefe; margin: auto; padding: 20px; border: 1px solid #888; width: 50%;">
      <h3>Create New Product</h3>
      <form @submit.prevent="createProduct">
        <label for="createProductName">Product Name:</label>
        <input type="text" id="createProductName" v-model="createProductData.product_name" required>

        <label for="createProductDescription">Product Description:</label>
        <textarea id="createProductDescription" v-model="createProductData.product_description" required></textarea>

        <button type="submit" style="background-color: #4CAF50; color: white; padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer;">Create Product</button>
      </form>
    </div>
  </div>
</div>`,

  data() {
    return {
      sections: [],
      products: [],
      msg: "",
      newProduct: {
        product_name: "",
        product_description: "",
        product_rate_per_unit: 0,
        product_unit: "",
        product_stock: 0,
        section_id: 1,
      },
      newsection: {
        section_name: "",
        section_description: "",
      },
      editModalOpen: false,
      editedsection: {
        section_id: null,
        section_name: "",
        section_description: "",
      },
      editProductOpen: false,
      createsectionPopup: false,
      createProductPopup: false,
      editedProduct: {
        product_id: null,
        product_name: "",
        product_description: "",
        product_rate_per_unit: 0,
        product_unit: "",
        product_stock: 0,
        section_id: 1,
      },
    };
  },

  mounted() {
    this.fetchProducts();
    this.fetchSections();
  },

  methods: {
    fetchProducts() {
      fetch("/api/all_Products")
        .then((response) => response.json())
        .then((data) => {
          this.products = data;
        })
        .catch((error) => {
          console.error("ERROR:", error);
        });
    },

    openCreatesectionPopup() {
      this.createsectionPopup = true;
    },

    closeCreatesectionPopup() {
      this.createsectionPopup = false;
    },

    openCreateProductPopup() {
      this.createProductPopup = true;
    },

    closeCreateProductPopup() {
      this.createProductPopup = false;
    },

    fetchSections() {
      fetch("/api/all_sections")
        .then((response) => response.json())
        .then((data) => {
          this.sections = data;
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    },

    createsection() {
      fetch("/api/create_section", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          section_name: this.newsection.section_name,  // <-- Updated to match your data structure
          section_description: this.newsection.section_description,  // <-- Updated to match your data structure
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          console.log("Section created", data);
          this.fetchSections();
          this.closeCreatesectionPopup();
        })
        .catch((error) => {
          console.error("Error", error);
        });
    },

    createProduct() {
      fetch("/api/create_Product", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          Product: this.newProduct.product_name,
          rating: this.newProduct.product_rate_per_unit,
          tags: this.newProduct.product_description,
          price: this.newProduct.product_rate_per_unit,
          shift: this.newProduct.product_unit,
          image_url: this.newProduct.product_stock,
          section_id: this.newProduct.section_id,
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          console.log("Product created", data);
          this.fetchProducts();
          this.fetchSections();
          this.closeCreateProductPopup();
        })
        .catch((error) => {
          console.error("Error", error);
        });
    },

    DeleteProduct(id) {
      fetch(`/api/delete_Product/${id}`, {
        method: "DELETE",
      })
        .then((response) => response.json())
        .then((data) => {
          console.log("Product Deleted", data);
          this.fetchProducts();
          this.fetchSections();
        });
    },

    Deletesection(id) {
      fetch(`/api/delete_section/${id}`, {
        method: "DELETE",
      })
        .then((response) => response.json())
        .then((data) => {
          console.log("section deleted:", data);
          this.msg = data.message;
          this.fetchProducts();
          this.fetchSections();
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    },

    confirmVenDelete(id) {
      if (window.confirm("Are you sure you want to delete this section?")) {
        this.Deletesection(id);
      }
    },

    confirmProductDelete(id) {
      if (window.confirm("Are you sure you want to delete this Product?")) {
        this.DeleteProduct(id);
      }
    },

    openEditModal(section) {
      this.editedsection.id = section.section_id;
      this.editedsection.name = section.section_name;
      this.editedsection.location = section.section_loc;
      this.editedsection.capacity = section.capacity;
      this.editModalOpen = true;
    },

    closeEditModal() {
      this.editModalOpen = false;
    },

    updatesection() {
      const id = this.editedsection.id;
      fetch(`/api/update_section/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: this.editedsection.name,
          location: this.editedsection.location,
          capacity: this.editedsection.capacity,
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          console.log("section updated", data);
          this.fetchsections();
          this.closeEditModal();
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    },

    openEditProduct(product) {
      this.editProductOpen = true;
      this.editedProduct.product_id = product.product_id;
      this.editedProduct.product_name = product.product_name;
      this.editedProduct.product_description = product.product_description;
      this.editedProduct.product_rate_per_unit = product.product_rate_per_unit;
      this.editedProduct.product_unit = product.product_unit;
      this.editedProduct.product_stock = product.product_stock;
      this.editedProduct.section_id = product.section_id;
    },

    closeEditProduct() {
      this.editProductOpen = false;
    },

    updateProduct() {
      const id = this.editedProduct.product_id;
      fetch(`/api/update_Product/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: this.editedProduct.product_name,
          description: this.editedProduct.product_description,
          rate: this.editedProduct.product_rate_per_unit,
          unit: this.editedProduct.product_unit,
          stock: this.editedProduct.product_stock,
          section_id: this.editedProduct.section_id,
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          console.log("Product updated", data);
          this.fetchProducts();
          this.fetchSections();
          this.closeEditProduct();
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    },
  },
};

export default AdminDashboard;
