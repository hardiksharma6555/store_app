import uuid
from flask import Flask, render_template, jsonify, request, abort
from flask_login import login_user , current_user
from api.resource import User, api
from models import db, User as user_model, Role,Section, Product, UserCart, Joint, UserTransaction
# from models import db, User as user_model, Role
from security import user_datastore, security
from flask_security import auth_required , roles_accepted

app = Flask(__name__)



app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///grocery_store.sqlite3"
app.config['SECRET_KEY'] = "thisissecretkey"
app.config["SECURITY_PASSWORD_SALT"] = "salt"
app.config['SECURITY_TRACKABLE'] = False 
app.config['WTF_CSRF_ENABLED'] = False
app.config["SECURITY_TOKEN_AUTHENTICATION_HEADER"] = "Authentication-Token"
app.config["SECURITY_PASSWORD_HASH"] = "bcrypt"

api.init_app(app)

security.init_app(app,user_datastore)
db.init_app(app)


@app.before_request
def create_db():
        db.create_all()

        if not user_datastore.find_role('admin'):
            
            admin_role = user_datastore.create_role(name='admin', description='Admin role')
            db.session.commit()

        if not user_datastore.find_user(email='admin@example.com'):
            
            admin_user = user_datastore.create_user(email='admin@example.com', username='admin', password='admin123')
            user_datastore.add_role_to_user(admin_user, admin_role)
            db.session.commit()


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/api/get_user_role', methods=['GET'])
def get_user_role():
    if current_user.has_role('admin'):
        return jsonify({'role': 'admin'}), 200
    else:
        return jsonify({'role': 'user'}), 200


@app.route('/api/get_user_name', methods=['GET'])
def get_user_info():
    if current_user.is_authenticated:
        user_id = current_user.id
        user_name = current_user.username
        return jsonify({'user_id': user_id, 'username': user_name}), 200
    else:
        return jsonify({'message': 'User not authenticated'}), 401

@app.route('/api/register', methods=['POST'])
def register():
    email = request.json.get('email')
    username = request.json.get('username')
    password = request.json.get('password')

    # Perform validation checks
    if not email or not username or not password:
        return jsonify({'message': 'Missing required fields'}), 400

    # Check if the user with the provided email already exists
    existing_user = user_model.query.filter_by(email=email).first()
    if existing_user:
        return jsonify({'message': 'User with this email already exists'}), 409

    # Check if the role with the name 'user' exists, and create one if not
    user_role = Role.query.filter_by(name='user').first()
    if not user_role:
        user_role = Role(name='user', description='Normal user role')
        db.session.add(user_role)
        db.session.commit()

    # Create a new user with the 'user' role
    new_user = user_model(email=email, username=username, password=password, active=1, roles=[user_role])
    db.session.add(new_user)
    db.session.commit()

    return jsonify({'message': 'User registered successfully'}), 201


@app.route("/api/create_section", methods=["POST"])
@roles_accepted('admin')
def api_create_section():
    section_name = request.json.get("section_name")
    section_description = request.json.get("section_description")
    s1 = Section(section_name=section_name, section_description=section_description)
    db.session.add(s1)
    db.session.commit()
    return jsonify({"id": s1.section_id, "section_name": s1.section_name, "section_description": s1.section_description})

@app.route('/api/all_sections', methods=['GET'])
@roles_accepted('admin', 'user')
def api_all_sections():
    sections = Section.query.all()
    return jsonify([{"section_id": s.section_id, 'section_name': s.section_name, 'section_description': s.section_description} for s in sections])

@app.route("/api/delete_section/<int:id>", methods=["DELETE"])
@roles_accepted('admin')
def api_delete_section(id):
    s1 = Section.query.filter_by(section_id=id).first()
    if not s1:
        abort(404)
    products = s1.products
    for product in products:
        db.session.delete(product)
        db.session.commit()
    db.session.delete(s1)
    db.session.commit()
    return jsonify({"message": 'Section (along with their products if any) got deleted successfully.'})

@app.route("/api/edit_section/<int:section_id>", methods=(["PUT"]))
@roles_accepted('admin')
def api_edit_section(section_id):
    section = Section.query.filter_by(section_id=section_id).first()
    if not section:
        abort(404)
    section.section_name = request.json["section_name"]
    section.section_description = request.json["section_description"]
    db.session.add(section)
    db.session.commit()
    sec = Section.query.filter_by(section_id=section_id).first()
    return jsonify({"id": sec.section_id, "section_name": sec.section_name, "section_description": sec.section_description})


if __name__ == "__main__":
    app.run(debug=True)
